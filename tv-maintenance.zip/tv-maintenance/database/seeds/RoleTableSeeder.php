<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('role')->delete();
        DB::table('role')->insert(
            [
                'name' 		=> 'Admin',
                'is_active' => 1,
            ],
            [
                'name'      => 'Basic',
                'is_active' => 1,
            ],
        );
    }
}
