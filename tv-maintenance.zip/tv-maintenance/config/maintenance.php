<?php

return [

    'allowed_users' => [
                    'testdev1',
                    'testdev2',
                    'cdsuministrado',
                    'emtan',
                    'omlanuza',
                    'ecvitug',
                    'ccmaghari',
                    'cfsolomon',
                    'hcmatutina',
                    'jorustia',
                    'kpbenipayo',
                    'msgaviola',
                    'mdtsuruya',
                    'nvnulud',
                    'ndfrancisco'
                ]

];
