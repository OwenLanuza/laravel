var ACCOUNTS = {
	build: function(){
		this.bind();
	},
	bind: function(){
		this.addUser();
	},
	addUser: function(){
		$(".btnAddUser").click(function(){
			var _self = $(this);

			var html = "<div class='row'>"+
							"<form name='frmNewUser' method='get' action='accounts/newuser'>"+
								"<div class=''></div>"+
								"<div class='form-group clearfix'>"+
									"<div class='col-md-3 text-left'>"+
										"<label class='control-label'>Search</label>"+
									"</div>"+
									"<div class='col-md-9 text-left'>"+
										"<div class='input-group'>"+
									      	"<input type='text' class='form-control' name='keyword' placeholder='Search for Username' autocomplete='off' required='required' />"+
									      	"<span class='input-group-btn'>"+
									        	"<button type='submit' class='btn btn-primary' type='button'>Go!</button>"+
									        	"<input type='hidden' name='_token' value='"+$("meta[name='csrf-token']").attr('content')+"'>"+
									      	"</span>"+
									    "</div>"+
									"</div>"+
								"</div>"+
							"</form>"+
							"<div class='userinfo'></div>"+
						"</div>";

			jAlert({
				'title' : "Add New User",
				'class' : 'modal-md',
				'msg': html,
				'footer': false
			});

			$("form[name='frmNewUser']").submit(function(e){
				var _self = $(this);
				var _uri  = _self.attr('action');
				$.ajax({
					url : _uri,
					data: _self.serialize(),
					method: 'GET',
					dataType: 'JSON',
					statusCode: {
					404: function(response) {
						toastr.error(response.responseJSON.message, "Error");
					},
					500: function(response){
						toastr.error(response.responseJSON.message, "Error");
						
					}
				}
				}).done(function(response){
					var role = "<option value=''>Select Role</option>";
					var account = "<option value=''>Select Account</option>";

					$.each(response.role, function(key, value){
						role += "<option value='"+value.id+"'>"+value.role+"</option>";
					});

					$.each(response.accounts, function(key, value){
						account += "<option value='"+value.id+"'>"+value.pseudonym+"</option>";
					});

					var html = "<div class='row'>"+
									"<hr/>"+
									"<form name='frmAddUser' method='post' action='accounts/user/add'>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Username :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<input type='text' value='"+response.userInfo.username+"' name='username' class='form-control' />"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>First Name :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<input type='text' name='fname' value='"+response.userInfo.fname+"' class='form-control' />"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Middle Initial :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<input type='text' name='mname' value='"+response.userInfo.mname+"' class='form-control' />"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Last Name :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<input type='text' name='lname' value='"+response.userInfo.lname+"' class='form-control' />"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Email :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<input type='text' value='"+response.userInfo.email+"' name='email' class='form-control' />"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Account :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<select class='form-control' name='account' required='required'>"+account+"</select>"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Role :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<select class='form-control' name='role' required='required'>"+role+"</select>"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-3 text-left'>"+
												"<label class='control-label'>Status :</label>"+
											"</div>"+
											"<div class='col-md-9 text-left'>"+
												"<select class='form-control' name='status'>"+
													"<option value='1'>Active</option>"+
													"<option value='0'>In Active</option>"+
												"</select>"+
											"</div>"+
										"</div>"+
										"<div class='form-group clearfix'>"+
											"<div class='col-md-12 text-right'>"+
												"<button type='submit' class='btn btn-md btn-primary' name='btnsave'>Save</button>&nbsp;"+
												"<button type='button' class='btn btn-md btn-default' data-dismiss='modal'>Close</button>"+
												"<input type='hidden' name='_token' value='"+$('meta[name="csrf-token"]').attr('content')+"'>"+
											"</div>"+
										"</div>"+
									"</form>"+
								"</div>";
					$(".userinfo").html(html);

					$("form[name='frmAddUser']").submit(function(e){
						var _self = $(this);
						var _url = _self.attr('action');

						$.ajax({
							url: _url,
							data: _self.serialize(),
							method: 'POST',
							dataType: 'json',
							statusCode: {
								404: function(response){
									toastr.error(response.responseJSON.message, "Error");
								},
								500: function(response){
									toastr.error(response.responseJSON.message, "Error");
								}
							},
						}).done(function(response){
							toastr.success(response.message, "Success");
							$(".userinfo").html('');
							$("input[name='keyword']").val('').focus();
						});

						e.preventDefault();
						e.stopPropagation();
					});
				})


				e.preventDefault();
				e.stopPropagation();
			})

		})
	}
}


$(document).ready(function(){
	ACCOUNTS.build();
})