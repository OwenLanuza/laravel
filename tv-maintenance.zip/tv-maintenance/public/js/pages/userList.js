var USERLIST = {
	userListUri: "userlist",
	userAccountUri: "users",
	build: function(){
		this.refreshUserListTable();
		this.bind();
	},
	bind: function(){
		this.editUser();
	},
	editUser: function(){
		$(".edit-user").unbind('click').click(function(){
			var _self = $(this);
			var aid = _self.attr('attr-aid');
			var uid = _self.attr('attr-uid');

			$.ajax({
				url: USERLIST.userAccountUri+"?aid="+aid+"&uid="+uid,
				method: "GET",
				dataType: "json",
				statusCode: {
					404: function(response) {
						toastr.error('No Record Found', "Error");
					},
					500: function(response){
						jAlert({
								'title' : 'Expired Token',
								'class': 'modal-sm',
								'msg' : '<div class="alert alert-danger" role="alert">'+
											'<label class="control-label">'+
												'Error, Your token has been expired. Once you close this alert popup it will automatically logout.'+
											'</label>'+
										'</div>',
								'footer': true
						});

						$(".c_alert").on('hidden.bs.modal', function(){
		                    window.location.href = "/logout";
		                });
						
					}
				}
			}).done(function(response){

				var role = "<option value=''>Select Role</option>";
				var account = "<option value=''>Select Account</option>";

				$.each(response.role, function(key, value){
					role += "<option value='"+value.id+"' "+((value.id == response.userData[0].role_id)?'selected=selected':'')+">"+value.role+"</option>";
				});

				$.each(response.accounts, function(key, value){
					account += "<option value='"+value.id+"' "+((value.id == response.userData[0].account_id)?'selected=selected':'')+">"+value.pseudonym+"</option>";
				});




				var html = "<div class='row'>"+
								"<form name='frmUser' method='post' action='user_file/update?uid="+response.userData[0].user_id+"&aid="+response.userData[0].account_id+"'>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Username :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<label class='control-label'>"+response.userData[0].username+"</label>"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Full Name :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<label class='control-label'>"+response.userData[0].fname+" "+response.userData[0].lname+"</label>"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Type :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<label class='control-label'>"+((response.userData[0].type)?response.userData[0].type.toUpperCase():'')+"</label>"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Email :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<input type='text' value='"+response.userData[0].email+"' name='email' class='form-control' />"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Role :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<select class='form-control' name='role'>"+role+"</select>"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Account :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<select class='form-control' name='account'>"+account+"</select>"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-3 text-left'>"+
											"<label class='control-label'>Status :</label>"+
										"</div>"+
										"<div class='col-md-9 text-left'>"+
											"<select class='form-control' name='status'>"+
												"<option value='1' "+((response.userData[0].is_active == 1)?'selected=selected':'')+">Active</option>"+
												"<option value='0' "+((response.userData[0].is_active == 0)?'selected=selected':'')+">In Active</option>"+
											"</select>"+
										"</div>"+
									"</div>"+
									"<div class='form-group clearfix'>"+
										"<div class='col-md-12 text-right'>"+
											"<button type='submit' class='btn btn-md btn-primary' name='btnsave'>Save</button>&nbsp;"+
											"<button type='button' class='btn btn-md btn-default' data-dismiss='modal'>Close</button>"+
											"<input type='hidden' name='_token' value='"+$('meta[name="csrf-token"]').attr('content')+"'>"+
										"</div>"+
									"</div>"+
								"</form>"+
							"</div>";
				jAlert({
					'title' : 'Edit User',
					'class': 'modal-md',
					'msg' : html,
					'footer': false
				});

				$("form[name='frmUser']").submit(function(e){
					var _self = $(this);
					var formData = _self.serialize();
					var uri = _self.attr('action')+'&'+formData;

					$.ajax({
						'url': uri,
						'method': 'POST',
						'dataType': 'json',
						'statusCode': {
							500: function(response){
								toastr.error("Something went wrong please contact the web admin", "Error");
							},
							404: function(response){
								toastr.error("Something went wrong please contact the web admin", "Error");
							}
						}
					}).done(function(response){
						toastr.success("You have successfully updated the record", "Success");
						$('#user-list').DataTable().destroy();
						USERLIST.refreshUserListTable();
						$(".c_alert").modal('hide');
					});

					e.stopPropagation();
					e.preventDefault();
				})

			})
		});
	},
	refreshUserListTable: function(){
		$('#user-list').DataTable({
        	scrollX: true,
            language: "Processing",
            drawCallback: function(){
			     USERLIST.editUser();   
			},
            ajax: {
                url: this.userListUri+'?id='+$("#user-list").attr('attr-id'),
                type: 'GET'
            },
            columns: [
                {
                	data: 'user_id',
                	   'orderable': false,
                	   'searchable': false
                },
                {data: 'username'},
                {data: 'fname'},
                {data: 'lname'},
                {data: 'email'},
                {data: 'role'},
                {data: 'type'},
                {
                	render: function(data, type, row) {
	                    return (row.is_active == 1)?"<span class='label label-primary'>Active</span>":"<span class='label label-danger'>In Active</span>"
	                },
            	},
                {
                    render: function(data, type, row) {
                        return "<label class='edit-user cur-pointer' attr-aid='"+row.account_id+"' attr-uid='"+row.user_id+"'><span class='fa fa-edit text-warning'></span></label>"
                    },
                    'orderable': false,
                    'searchable': false,
                }
            ],
            dom: '<"html5buttons"B>lTfgitp',
            buttons: [
                {extend: 'excel'},
                {extend: 'print'},
            ],
            columnDefs: [
                {
                    'targets': "_all",
                    'searchable': true,
                    'className': 'text-center',
                    'orderable': true
                },
            ]
        });

        $.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) { 
        	$('#user-list').DataTable().destroy()
        	$('#user-list').DataTable({
		    	"language": {
		    		"emptyTable": "No Records Found!"
		    	}
		    })
		};


	}
}


$(document).ready(function(){
	USERLIST.build();
})