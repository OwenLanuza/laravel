function jAlert(params)
{
    var c_alert         = $(".c_alert");
    $(".modal-dialog", c_alert).addClass(params.class);
    $(".modal-title", c_alert).html(params.title);
    $(".modal-body", c_alert).html(params.msg);
   
    $(".modal-footer",c_alert).removeClass('hide');
    if(!params.footer)
    {
        $(".modal-footer",c_alert).addClass('hide');
    }
    c_alert.modal({backdrop: 'static', keyboard: false});

}
