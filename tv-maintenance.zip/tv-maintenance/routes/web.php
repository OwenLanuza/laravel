<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Redirect::to('login');
});

Auth::routes();

Route::group([
	'middleware' => ['auth', 'verify.user'],
    'prefix' => 'admin',
    'namespace' => 'Admin'],
    function () {
        Route::get('accounts', "AccountsController@index");
        Route::get('accounts/list', "AccountsController@getAccountList");
        Route::get('accounts/userlist', "AccountsController@getAccountUserList");
        Route::get('accounts/users', "AccountsController@getAccountUser");
        Route::get('accounts/newuser', "AccountsController@getLdapUser");

        Route::post('accounts/user_file/update', "AccountsController@updateAccountUser");
        Route::post('accounts/user/add', "AccountsController@setNewUser");
    }
);


Route::get('/logout', function(){
    Auth::logout();
    Session::flush();
    return Redirect::to('/login')
        ->with('message', 'You have successfully logout.')
        ->with('alertType', 'alert-success');
});