<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element">
                    <img src="{{ asset('images/totalview_logo.png') }}" class="img-responsive center-block">
                    <p class="m-t-lg">
                        <span><strong>{{ Auth::user()->name }}</strong></span>
                    </p>
                </div>
                <div class="logo-element">
                    <img src="{{ asset('images/tv_icon.png') }}" class="img-responsive center-block">
                </div>
            </li>
            <li class="{{ (Request::segment(2)=='accounts')?'active':'' }}">
                <a href="{{ URL('admin/accounts') }}"><i class="fa fa-medkit"></i> <span class="nav-label">Accounts</span></a>
            </li>
        </ul>

    </div>
</nav>