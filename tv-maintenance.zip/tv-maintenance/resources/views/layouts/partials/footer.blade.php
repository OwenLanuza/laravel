<div class="footer">
    <div class="pull-right">Powered By <strong>SW Health Application Development Team</strong></div>
    <div>
        Shearwater Health TotalView &copy; {{ date('Y') }}
    </div>
</div>