<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2 id="page-header-title" class="bindPageTitleBreadCrumbs">{{ !empty($title)?$title:"" }}</h2>
    </div>
    <div class="col-lg-2"></div>
</div>
