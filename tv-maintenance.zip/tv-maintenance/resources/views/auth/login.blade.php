@extends('layouts.app')

@section('content')
<div class="container loginPanel animated fadeInDown">
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
                <div class="panel-body text-center">
                    <div class="row m-l m-r">
                        <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                            {{ csrf_field() }}
                            <div class="form-group pd">
                                <img src="{{ asset('images/totalview2_logo.png') }}" class="img-responsive center-block" />
                            </div>
                            @if(Session::has('message'))
                                <div class="alert {{ Session::get('alertType') }} text-left" role="alert">
                                    <label class="control-label"><span class="fa fa-exclamation-triangle"></span>&nbsp;{{ Session::get('message') }}</label>
                                </div>
                            @endif
                            <h3>Welcome to TotalView</h3>
                            <p class="login-sub-header"> Please use your NT credentials to Login.</p>
                            <div class="form-group{{ $errors->has('username') ? ' has-error' : '' }}">
                                <div class="col-md-12">
                                    <input id="username" type="text" class="form-control" name="username" value="" required autofocus>

                                    @if ($errors->has('username'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('username') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                                <div class="col-md-12">
                                    <input id="password" type="password" class="form-control" name="password" value="" required>
                                    @if ($errors->has('password'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group text-right">
                                <div class="col-md-12">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group clearfix">
                                <div class="col-md-12 col-xs-12 clearfix">
                                    <button type="submit" class="btn btn-primary col-md-12 col-xs-12">
                                        Login
                                    </button>
                                </div>
                            </div>

                            <div class="form-group">
                                 <p>
                                    <small class="login-footer">SWHealth TotalView All Rights Reserved © 2017</small>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
