@extends('layouts.app')

@section('page-style')
<link href="{{ asset('css/plugins/dataTables/datatables.min.css') }}" rel="stylesheet">
@endsection

@section('content')
<div class="row">    
	<div class="ibox float-e-margins">
        <div class="ibox-title">User List</div>
        <div class="ibox-content">
        	<table id="user-list" attr-id="{{ Request::get('id') }}" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
        		<thead>
            		<tr role="row">
            			<th>User ID</th>
            			<th>Username</th>
            			<th>First Name</th>
            			<th>Last Name</th>
            			<th>Email</th>
            			<th>Role</th>
            			<th>Type</th>
            			<th>Status</th>
            			<th class="text-center">Action</th>
            		</tr>
        		</thead>
        	</table>
        </div>
    </div>
</div>
@endsection

@section('page-script')
	<script type="text/javascript" src="{{ asset('js/plugins/jeditable/jquery.jeditable.js') }}"></script>
	<script type="text/javascript" src="{{ asset('js/plugins/dataTables/datatables.min.js') }}"></script>
	<script type="text/javascript" src="{{ asset('js/pages/userList.js') }}"></script>
@endsection
