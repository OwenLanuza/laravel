@extends('layouts.app')

@section('content')
<div class="row">
	<div class="col-md-5">       
		<div class="ibox float-e-margins">
	        <div class="ibox-title">
	        	<h5>Account List</h5>
	        	<div class="ibox-tools">
	        		<button class="btn btn-primary btn-sm btnAddUser">Add User</button>
	        	</div>
	        </div>
	        <div class="ibox-content">
	            <div class="table-responsive">
	            	<table class="table table-hover table-striped">
	            		<thead>
		            		<tr>
		            			<th>Account Name</th>
		            			<th class="text-center">Action</th>
		            		</tr>
	            		</thead>
	            		<tbody>
		            		@if(!empty($results))
		            			@foreach($results as $row)
		            				<tr>
		            					<td>{{ $row['pseudonym'] }}</td>
		            					<td class="text-center">
		            						<a href="{{ url('admin/accounts/list').'?id='.base64_encode($row['id']) }}" title="Edit">
		            							<span class="fa fa-edit text-warning"></span>&nbsp;
		            						</a>
		            					</td>
		            				</tr>
		            			@endforeach
		            		@else
		            			<tr>
		            				<td colspan="2" class="text-center">No Records</td>
		            			</tr>
		            		@endif
	            		</tbody>
	            	</table>
	            </div>
	        </div>
	    </div>
    </div>
</div>
@endsection
@section('page-script')
	<script type="text/javascript" src="{{ asset('js/pages/account.js') }}"></script>
@endsection