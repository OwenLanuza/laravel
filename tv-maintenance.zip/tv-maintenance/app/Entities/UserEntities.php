<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class UserEntities extends Model
{
	protected $table = "user";

	protected $connection;

	protected $primaryKey = "userid";

	public $timestamps = false;

	protected $guarded = [];

}