<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class RoleEntities extends Model
{
	protected $table = "role";
}