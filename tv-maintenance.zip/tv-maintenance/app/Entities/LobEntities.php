<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class LobEntities extends Model
{
	protected $table = "lob";
}