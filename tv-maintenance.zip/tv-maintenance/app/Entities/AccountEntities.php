<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class AccountEntities extends Model
{
	protected $table = "account";
}