<?php

namespace App\Entities;

use Illuminate\Database\Eloquent\Model;

class UserFileEntities extends Model
{
	protected $table = "user_file";
}