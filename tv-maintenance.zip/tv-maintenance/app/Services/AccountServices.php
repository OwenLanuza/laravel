<?php

namespace App\Services;

use App\Repositories\Contracts\AccountInterface;
use App\Repositories\Contracts\RoleInterface;
use App\Repositories\Contracts\UserFileInterface;
use Adldap, Config, Validate;

class AccountServices
{
	protected $accountInterface;
	protected $roleInterface;
	protected $userFileInterface;

	/**
     * AccountServices constructor.
     * @param AccountInterface $accountInterface
     */
	function __construct(
		AccountInterface $accountInterface,
		RoleInterface $roleInterface,
		UserFileInterface $userFileInterface
	)
	{
		$this->accountInterface = $accountInterface;
		$this->roleInterface = $roleInterface;
		$this->userFileInterface = $userFileInterface;
	}

	public function getActiveAccounts()
	{
		return $this->accountInterface->findByEntities(
											['is_active' => 1], 
											'account'
										)
										->get()
										->toArray();
	}

	public function getUsersInAccounts($id)
	{
		$accounts = $this->accountInterface->find('account', $id)->toArray();
		
		$arr_data = array();
		$arr_data['returns'] = false;
		$arr_data['message'] = "No Records Found";
		$arr_data['statusCode'] = 404;

		//validate if Account ID is exist
		if (!empty($accounts)) {
			if ($accounts['id'] == $id) {
				$results = $this->accountInterface->findByEntities(
														[	
															'account_id' => (int)$id
														], 'userFile')
														->get()
														->toArray();
				if ($results) {
					$arr_data['returns'] = true;
					$arr_data['statusCode'] = 200;
					$arr_data['message'] = "";
					foreach ($results as $row) {
							
						$role = $this->accountInterface->findByEntities(
															[
																'id' => $row['role_id']
															], 'role')
															->get()
															->toArray();

						$arr_data['data'][] = array(
												'user_id'		=> $row['user_id'],
												'username'		=> $row['username'],
												'fname'			=> $row['fname'],
												'lname'			=> $row['lname'],
												'mname'			=> $row['mname'],
												'email'			=> $row['email'],
												'role'			=> $role[0]['role'],
												'role_id'		=> $role[0]['id'],
												'type'			=> $row['type'],
												'account_id'	=> $row['account_id'],
												'is_active'		=> $row['is_active']
											   );
					}
				}
				
			}

		}
		return $arr_data;
	}

	public function getAccountUser($data)
	{
		$arr_data = array();
		$arr_data['returns'] = false;
		$arr_data['statusCode'] = 404;
		
		$userData = $this->accountInterface->findByEntities(
												[
													'user_id' => $data['uid'],
													'account_id' => $data['aid']
												], 'userFile')
												->get()
												->toArray();

		if (!empty($userData)) {
			if ($data['aid'] == trim($userData[0]['account_id'])) {

				$arr_data['statusCode'] = 200;
				$arr_data['accounts'] = $this->accountInterface->findByEntities(
																	['is_active' => 1], 'account')
																	->get()
																	->toArray();

				$arr_data['role'] = $this->roleInterface->findByEntities(
													['is_active' => 1],
													'role')
													->get()
													->toArray();

				array_shift($arr_data['role']);

				$arr_data['userData'] = $userData;
			}
		}
		return $arr_data;
	}

	public function setNewUser($data)
	{
		$arr_data = array();
		$arr_data['returns'] = false;
		$arr_data['statusCode'] = 404;

		$accounts = $this->accountInterface->find('account', $data['account'])->toArray();
		
		$data['db_name'] = Config::get('database.suffix').$accounts['db_name'];
		$data['db_qa'] = (!empty($accounts['db_qa']))?$accounts['db_qa']:'qa';
		$data['db_qa'] = Config::get('database.suffix').$data['db_qa'];

		$results = $this->userFileInterface->saveUser($data);

		if ($results['returns']) {
			$arr_data['returns'] = true;
			$arr_data['statusCode'] = 200;
		}
		$arr_data['message'] = $results['message'];
		return $arr_data;
		
	}

	public function getLdapUser($data)
	{

		$arr_data = array();
		$arr_data['returns'] = false;
		$arr_data['statusCode'] = 404;
		
		$lDapUser = Adldap::search()->users()->find($data['keyword']);

		if (!empty($lDapUser->exists) && $lDapUser->exists == true) {

			$username = $lDapUser->samaccountname[0];
			$fname = $lDapUser->givenname[0];
			$lname = $lDapUser->sn[0];
			$mname = $lDapUser->initials[0];
			$email = $lDapUser->userprincipalname[0];

			$results = $this->accountInterface->findByEntities(['username' => $username], 'userFile')->get()->toArray();

			if (empty($results)) {
				$arr_data['returns'] = true;
				$arr_data['statusCode'] = 200;
				$arr_data['accounts'] = $this->accountInterface->findByEntities(
																	['is_active' => 1], 'account')
																	->get()
																	->toArray();

				$arr_data['role'] = $this->roleInterface->findByEntities(
													['is_active' => 1],
													'role')
													->get()
													->toArray();
				array_shift($arr_data['role']);

				$arr_data['userInfo'] = array(
											'username'  => $username,
											'email'		=> $email,
											'fname'		=> $fname,
											'lname'		=> $lname,
											'mname'		=> $mname
										);
			} else {
				$arr_data['message'] = "User already exist!";
			}
		}else {
			$arr_data['message'] = "User not found!";
		}

		return $arr_data;
	}

	public function updateAccountUser($data)
	{
		$arr_data = array();
		$arr_data['returns'] = false;
		$arr_data['statusCode'] = 404;

		$accounts = $this->accountInterface->find('account', $data['aid'])->toArray();
		$data['db_name'] = Config::get('database.suffix').$accounts['db_name'];

		$getAccountQa = $this->accountInterface->find('account', $data['account'])->toArray();

		$data['db_qa'] = (!empty($getAccountQa['db_qa']))?$getAccountQa['db_qa']:'qa';
		$data['db_qa'] = Config::get('database.suffix').$data['db_qa'];

		$results = $this->userFileInterface->updateUser($data);
		if ($results['returns']) {
			$arr_data['returns'] = true;
			$arr_data['statusCode'] = 200;
		}
		$arr_data['message'] = $results['message'];
		return $arr_data;
	}

	public function setEnvironmentValue($arr_env)
    {
        $envFile = app()->environmentFilePath();

        $str = file_get_contents($envFile);

        $strCount = strlen($str);
        $line = "";
        $word = "";
        for ($i = 0; $i< $strCount; $i++) {
            $getChar = substr($str, $i, 1);
            $line .= $getChar;
            if (preg_match('/[\n]/s', $line, $matches, PREG_OFFSET_CAPTURE)) {
                $value = explode("=", $line);
                if (array_key_exists($value[0], $arr_env)) {
                    $word .= $value[0]."=".$arr_env[$value[0]]."\r\n";
                } else {
                    $word .= $line;
                }
                $line = "";
            }
        }
        $fp      = fopen($envFile, 'w');
        fwrite($fp, $word);
        fclose($fp);
    }
}