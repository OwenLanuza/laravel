<?php

namespace App\Repositories;

use App\Repositories\Contracts\MainInterface;
use App\Repositories\MainRepo;
use App\Entities\UserFileEntities;
use App\Entities\LobEntities;
use App\Entities\AccountEntities;
use App\Entities\RoleEntities;

class MainRepo  implements MainInterface
{
	protected $userFile;
	protected $lob;
	protected $account;
	protected $role;

	public function __construct(
		LobEntities $lob,
		UserFileEntities $userFile,
		AccountEntities $account,
		RoleEntities $role
	)
	{
		$this->lob = $lob;
		$this->userFile = $userFile;
		$this->account = $account;
		$this->role = $role;
	}

	public function find($entities, $id)
	{
		return $this->{$entities}->find($id);
	}

	public function findByEntities($data, $entities, $groupBy = array(), $orderBy = '', $sort = 'ASC')
	{
		$return = $this->{$entities}->where($data);
		if (!empty($groupBy)) {
			$return->groupBy($groupBy);
		}
		if ($orderBy != "") {
			$return->orderBy($orderBy, $sort);
		}
		return $return;
	}
}