<?php

namespace App\Repositories;

use App\Repositories\Contracts\LobInterface;
use App\Repositories\MainRepo;
use App\Entities\LobEntities;

class LobRepo extends MainRepo implements LobInterface
{
	protected $lob;

}