<?php

namespace App\Repositories;

use App\Repositories\Contracts\AccountInterface;
use App\Repositories\MainRepo;
use App\Entities\AccountEntities;

class AccountRepo extends MainRepo implements AccountInterface
{
	protected $account;
}