<?php

namespace App\Repositories\Contracts;

interface UserFileInterface
{
	public function saveUser($data);

	public function updateUser($data);
}