<?php

namespace App\Repositories\Contracts;

interface MainInterface
{
	public function find($entities, $id);
	
	public function findByEntities($data, $entities, $groupBy, $orderBy, $sort);
}