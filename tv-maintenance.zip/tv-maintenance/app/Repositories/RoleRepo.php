<?php

namespace App\Repositories;

use App\Repositories\Contracts\RoleInterface;
use App\Entities\RoleEntities;

class RoleRepo extends MainRepo implements RoleInterface
{
	protected $role;

}