<?php

namespace App\Repositories;

use App\Repositories\Contracts\UserFileInterface;
use App\Entities\UserEntities;
use Illuminate\Support\Facades\Auth;
use DB, Log, Schema, Config;

class UserFileRepo extends MainRepo implements UserFileInterface
{
	protected $userFile;

	public function saveUser($data)
	{
		$arr_returns = array();
		$arr_return['returns'] = false;

		DB::beginTransaction();
		DB::connection($data['db_name'])->beginTransaction();
		DB::connection('tv_qa')->beginTransaction();
		DB::connection('tv_useraccess')->beginTransaction();

		try{

			$userId = date('U');

			//insert into maintenance master user_file
			$this->userFile->insert([
								'username'		=> $data['username'],
								'user_id'		=> $userId,
								'fname'			=> $data['fname'],
								'lname'			=> $data['lname'],
								'mname'			=> ($data['mname']!='')?$data['mname']:" ",
								'email'			=> $data['email'],
								'account_id'	=> $data['account'],
								'role_id'		=> $data['role'],
								'is_active'		=> $data['status'],
								'created_at'	=> date('Y-m-d H:i:s'),
								'created_by' 	=> Auth::user()->username
							]);

			//insert into account database
			$users    = new UserEntities;
			$users->setTable($data['db_name'].'.user');
			$users->setConnection($data['db_name']);
			$users->insert([
						'userid'	=> $userId,
						'username'	=> $data['username'],
						'email'		=> $data['email'],
						'fname'		=> $data['fname'],
						'lname'		=> $data['lname'],
						'mname'		=> ($data['mname']!='')?$data['mname']:" ",
						'roleid'	=> $data['role'],
						'statusid'	=> $data['status'],
						'accountid'	=> $data['account'],
						'createdate'=> date('Y-m-d H:i:s'),
						'createdby' => Auth::user()->username
					]);

			//insert to QA Database
			$users = new UserEntities;
			$users->setConnection($data['db_qa']);
			$users->setTable($data['db_qa'].'.user_'.$data['account']);
			$users->insert([
						'userid'	=> $userId,
						'username'	=> $data['username'],
						'email'		=> $data['email'],
						'fname'		=> $data['fname'],
						'lname'		=> $data['lname'],
						'mname'		=> ($data['mname']!='')?$data['mname']:" ",
						'roleID'	=> $data['role'],
						'statusID'	=> $data['status'],
						'accountIDa'=> $data['account'],
						'createdate'=> date('Y-m-d H:i:s'),
						'createdby' => Auth::user()->username
					]);

			//insert to TV USERACCESS
			$users = new UserEntities;
			$users->setConnection('tv_useraccess');
			$users->setTable('tv_useraccess.useraccess');
			$users->insert([
						'userid'	=> $userId,
						'roleid'	=> 1,
						'totalview'	=> 1,
						'accountid'	=> $data['account'],
						'username'	=> $data['username']
					]);



			DB::commit();
			DB::connection($data['db_name'])->commit();
			DB::connection('tv_qa')->commit();
			DB::connection('tv_useraccess')->commit();


			$arr_return['returns'] = true;
			$arr_return['message'] = "Record Save";

		} catch(\Exception $e) {
			Log::warning(sprintf('Users Save : Exception: %s', $e->getMessage()));
			DB::rollback();
        	DB::connection($data['db_name'])->rollback();
        	DB::connection('tv_qa')->rollback();
        	$arr_return['message'] = $e->getMessage();
		}

		return $arr_return;

	}

	public function updateUser($data)
	{
		$arr_returns = array();
		$arr_return['returns'] = false;

		DB::beginTransaction();
		DB::connection($data['db_name'])->beginTransaction();
		DB::connection('tv_qa')->beginTransaction();

		$accountDB = '';

		//get account entities
		if ($data['aid'] != $data['account']) {
			$account 	= $this->account->where('id', $data['account'])->where('is_active', 1)->first()->toArray();
			$accountDB 	= Config::get('database.suffix').$account['db_name'];
			DB::connection($accountDB)->beginTransaction();
		}

		try{
			
			$users    = new UserEntities;
			$users->setTable($data['db_name'].'.user');
			$users->setConnection($data['db_name']);
			$userData = $users->where('userid', $data['uid'])->where('accountid', $data['aid']);
			$getUser  = $userData->get();
	
			//for updating
			if ($getUser[0]->accountid == $data['account']) {
				$userData->update([
								'email'		=> $data['email'],
								'roleid'	=> $data['role'],
								'statusid' 	=> $data['status'],
								'updatedby' => AUTH::user()->username,
								'updatedate'=> date('Y-m-d H:i:s')
							]);
			} else {

				//for transferring account
				$userData->update([
								'statusid'  => 0,
								'updatedby' => AUTH::user()->username,
								'updatedate'=> date('Y-m-d H:i:s')
							]);

				$users = new UserEntities;
				$users->setTable($accountDB.'.user');
				$users->setConnection($accountDB);
				$switchAccount = $users->where('userid', $data['uid'])->where('accountid', $data['account']);
				$getData = $switchAccount->get();

				if ($getData->count() > 0) {
					$switchAccount->update([
										'email'		=> $data['email'],
										'roleid'	=> $data['role'],
										'statusid' 	=> $data['status']
									]);
				}else {
					$saveNew = $getUser;
					$saveNew = $saveNew->first()->toArray();
					$saveNew['roleid'] 		= $data['role'];
					$saveNew['accountid'] 	= $data['account'];
					$saveNew['statusid'] 	= 1;
					$saveNew['createdate'] 	= date('Y-m-d H:i:s');
					$saveNew['createdby']  	= AUTH::user()->username;
					$saveNew['updatedby']  	= '';
					$saveNew['updatedate']  = '';

					unset($saveNew['siteID']);
					unset($saveNew['sampType']);
					unset($saveNew['caseCnt']);

					$switchAccount->create($saveNew);
				}


				DB::connection($accountDB)->commit();
			}

			DB::connection($data['db_name'])->commit();

			$getUser = $getUser->first()->toArray();
			$username = $getUser['username'];

			$getAcct = $this->account->find($data['aid']);
			$getQaDb = (!empty($getAcct->db_qa))?$getAcct->db_qa:'qa';
			$getQaDb = Config::get('database.suffix').$getQaDb;

			$users = new UserEntities;
			$users->setConnection($getQaDb);

			$users->setTable($getQaDb.'.user_'.$data['aid']);

			if ($data['aid'] != $data['account']) {
	
				$tempUser = $users->where('username', $username);

				$tempUser->update([
								'statusID' 	=> 0
							]);

				$tempUser = $tempUser->first()->toArray();

				$tempUser['statusID']   = 1;
				$tempUser['createdate'] = date('Y-m-d H:i:s');
				$tempUser['createdby'] 	= AUTH::user()->username;

				$users = new UserEntities;
				$users->setConnection($data['db_qa']);
				$users->setTable($data['db_qa'].'.user_'.$data['account']);
				$qa = $users->where('username', $username);

				if ($qa->get()->count() > 0) {
					$users->update([
								'email'		=> $data['email'],
								'roleID'	=> $data['role'],
								'statusID' 	=> $data['status'],
								'updatedby' => AUTH::user()->username,
								'updatedate'=> date('Y-m-d H:i:s')
							]);
				}else
				{
					$users->insert($tempUser);
				}

				

			} else {
				$users->where('username', $username)->update([
										'email'		=> $data['email'],
										'roleID'	=> $data['role'],
										'statusID' 	=> $data['status'],
										'updatedby' => AUTH::user()->username,
										'updatedate'=> date('Y-m-d H:i:s')
									]);;

			}

			DB::connection('tv_qa')->commit();


			$userFile = $this->userFile->where('user_id', $data['uid'])->where('account_id', $data['aid']);
			$userFile->update([
							'email'		=> $data['email'],
							'role_id'	=> $data['role'],
							'account_id'=> $data['account'],
							'is_active' => $data['status'],
							'updated_by'=> AUTH::user()->username,
							'updated_at'=> date('Y-m-d H:i:s')
						]);

			DB::commit();
			$arr_return['returns'] = true;
			$arr_return['message'] = "Record Save.";
		} catch(\Exception $e) {
			Log::warning(sprintf('Users Update Exception: %s', $e->getMessage()));
			DB::rollback();
        	DB::connection($data['db_name'])->rollback();
        	DB::connection('tv_qa')->rollback();
        	if ($accountDB != "") {
        		DB::connection($accountDB)->rollback();
        	}
        	$arr_return['message'] = $e->getMessage();
		}

		return $arr_return;
	}
}