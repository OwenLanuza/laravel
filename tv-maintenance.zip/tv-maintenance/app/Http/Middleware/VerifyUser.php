<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Redirect;

class VerifyUser
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::user()->is_active==0) {
            Auth::logout();
            return Redirect::to('login')->withMessage('Invalid User or User does not exist. Please contact the Web Admin.');
        }

        return $next($request);
    }
}
