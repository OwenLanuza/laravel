<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Services\AccountServices;
use Config;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/admin/accounts';

    private $accountServices;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(AccountServices $accountServices)
    {
        $this->accountServices = $accountServices;
        $this->middleware('guest')->except('logout');
    }
    
    public function login(Request $request)
    {
        if ($lockedOut = $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);
            return $this->sendLockoutResponse($request);
        }

        if (!in_array(strtolower($request->get('username')), Config('maintenance.allowed_users'))) {
            return redirect()->to('login')
                    ->with('message', 'Username are not allowed to login to this portal')
                    ->with('alertType', 'alert-danger');
        }

        $remember_me = $request->has('remember') ? true : false;

        //this will set the connection string for the default LDAP base on users credential
        Config(['adldap.connections.default.connection_settings.admin_username' => $request->get('username')]);
        Config(['adldap.connections.default.connection_settings.admin_password' => $request->get('password')]);

        //this will setup your environment if you need to wr
        $this->accountServices->setEnvironmentValue([
                                    'ADLDAP_ADMIN_USERNAME' => $request->get('username'),
                                    'ADLDAP_ADMIN_PASSWORD' => $request->get('password')
                                   ]);


        try {
            Auth::attempt($request->only(['username', 'password'], $remember_me));
            return redirect()->to('admin/accounts');
        } catch(\Exception $e) {
            return redirect()->to('login')
            ->with('message', $e->getMessage())
            ->with('alertType', 'alert-danger');
        }
    }
}
