<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Response;
use App\Services\AccountServices;

class AccountsController extends Controller
{
    protected $accountServices;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(AccountServices $accountServices)
    {
        $this->accountServices = $accountServices;
    }

    /**
     * Show the application Accounts.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $results = $this->accountServices->getActiveAccounts();

        $data = array(
                    'title' => 'Account',
                    'results' => $results
                );

        return view('pages.account.index', $data);
    }

    public function getAccountList()
    {
        $data = array(
                    'title' => 'User List'
                );

       return view('pages.account.subpages.user_list', $data);
    }

    public function getAccountUserList(Request $request)
    {
        $id = base64_decode($request->get('id'));

        $results = $this->accountServices->getUsersInAccounts($id);

        return Response::json($results, $results['statusCode']);
    }

    public function setNewUser(request $request)
    {
        $results = $this->accountServices->setNewUser($request->all());
        return Response::json($results, $results['statusCode']);
    }

    public function getAccountUser(Request $request)
    {
        $results = $this->accountServices->getAccountUser($request->all());
        return Response::json($results, $results['statusCode']);
    }

    public function getLdapUser(Request $request)
    {
        $results = $this->accountServices->getLdapUser($request->all());
        return Response::json($results, $results['statusCode']);
    }

    public function updateAccountUser(Request $request)
    {
        $results = $this->accountServices->updateAccountUser($request->all());
        return Response::json($results, $results['statusCode']);
    }

}
