<?php 

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppRepositoryProvider extends ServiceProvider 
{
    public function boot() {}

    public function register() {
        $models = array(
        	'Main',
            'Account',
            'Lob',
            'Role',
            'UserFile'
        );

        foreach ($models as $idx => $model) {
            $this->app->bind("App\Repositories\Contracts\\{$model}Interface", "App\Repositories\\{$model}Repo");
        }
    }
}